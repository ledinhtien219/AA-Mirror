# Hướng dẫn tạo APK AnyAuto Split cho Android Auto

## Trong bản ZIP có gì?

Đây là **mã nguồn chỉnh sửa** AnyAuto (chia đôi màn hình thành 2 vùng), không phải APK đã biên dịch.
Tệp `build.sh` là quy trình tạo `anyauto.apk` của dự án. Thư mục `.github/workflows/build-apk.yml` được thêm để GitHub Actions tự biên dịch APK qua máy chủ Ubuntu, không cần cài Android Studio.

**Trạng thái kiểm tra:** đã kiểm tra cú pháp 25 tệp Java, 24 tệp XML, shell script và Python; **chưa biên dịch hoặc chạy thử trên điện thoại/xe**. Bản chia đôi màn hình trong README của mã nguồn ghi rõ chưa được biên dịch trước đó, do vậy có thể phát sinh lỗi biên dịch hoặc lỗi khi chạy.

## Cách 1: Tạo APK miễn phí bằng GitHub Actions (dễ nhất)

1. Giải nén file ZIP này trên máy tính.
2. Đăng nhập https://github.com và tạo một repository (nên chọn Private).
3. Trong repository, chọn **Add file > Upload files**. Tải lên **nội dung bên trong thư mục `AnyAuto-main`**, không tải file ZIP trực tiếp. Đảm bảo cả thư mục ẩn `.github/workflows` cũng có trong repository.
4. Chọn **Commit changes** lên nhánh `main`.
5. Mở tab **Actions** và chọn **Build AnyAuto Split APK**. Workflow thường chạy sau khi commit; nếu chưa chạy, bấm **Run workflow**.
6. Mở kết quả chạy. Nếu trạng thái xanh, kéo xuống **Artifacts**, tải **AnyAuto-Split-APK**.
7. Giải nén artifact: bên trong có `AnyAuto-Split.apk`, `apk-sha256.txt` và `build-verification.log`.

Nếu bước build đỏ, mở log của bước bị lỗi. **Đừng đổi tên file ZIP thành .apk:** đó không phải APK hợp lệ.

### Lưu ý về chữ ký

Workflow tạo một keystore mới cho mỗi lần build. Điều này có nghĩa là APK mới thường không cập nhật trực tiếp lên APK đã cài bằng khóa khác; có thể phải gỡ bản cũ trước (có thể mất dữ liệu/cài đặt của ứng dụng). Nếu cần phát hành nhiều phiên bản cập nhật mà không gỡ cài đặt, phải thiết lập một khóa ký riêng, được lưu bí mật và dùng lại trong mọi lần build.

## Cách 2: Build trên Linux hoặc macOS

Cài Android SDK có `platforms;android-35` và `build-tools;35.0.0`, JDK 17+ và Python 3, rồi chạy trong thư mục `AnyAuto-main`:

```sh
export ANDROID_HOME=/path/to/android-sdk
export JAVA_HOME=/path/to/jdk
./build.sh verify
```

APK tạo ra sẽ ở `AnyAuto-main/anyauto.apk`. Lần build đầu cần kết nối internet để tải thư viện từ Google Maven/Maven Central.

## Cài đặt trên điện thoại cho Android Auto

Dựa trên README của chính mã nguồn:

1. Dùng điện thoại Android 10 trở lên; cài **Shizuku** (https://shizuku.rikka.app/) và cho chạy đúng hướng dẫn.
2. Cài **UnknownAuto** từ https://github.com/GitMag/UnknownAuto/releases/latest.
3. Trong UnknownAuto, chọn **Load APK or XAPK**, mở file APK vừa biên dịch rồi chọn **Install**. Cách này nhằm tránh việc Android Auto bỏ qua các ứng dụng Car App Library được cài ngoài Google Play.
4. Mở AnyAuto trên điện thoại, cấp quyền Shizuku và quyền bổ sung liên quan đến vị trí/thông báo nếu bạn dùng tính năng tốc độ/nhạc.
5. Chọn ứng dụng muốn hiển thị. Vào **Android Auto > Customize launcher** để thêm AnyAuto nếu chưa thấy.

**Cảnh báo:** nguồn chỉnh sửa chưa được thử nghiệm trên xe. Chỉ sử dụng nội dung có thể gây mất tập trung (chẳng hạn video) khi xe đã đỗ an toàn; tuân thủ luật giao thông.

## Tệp chính

- `build.sh`: biên dịch, đóng gói, ký và kiểm tra APK.
- `.github/workflows/build-apk.yml`: chạy quá trình biên dịch trên GitHub.
- `AndroidManifest.xml`: khai báo ứng dụng và dịch vụ Android Auto.
- `src/`: mã Java và AIDL của ứng dụng.
- `res/`: giao diện và tài nguyên.
