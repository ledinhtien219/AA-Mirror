package com.mag.anyauto;

import android.content.ComponentName;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.os.Handler;
import android.provider.Settings;
import android.util.Log;

import java.util.List;

/**
 * The song on the top bar: the active media session's title, artist, cover and play state, and
 * its previous / play-pause / next buttons. Needs notification access (see
 * {@link MediaListenerService}); without it there is simply no song.
 */
final class MediaWatcher {
    private static final String TAG = "AnyAuto";

    interface Listener {
        /** Any thread. */
        void onMedia();
    }

    private final Context context;
    private final Listener listener;
    private final Handler handler;
    private MediaSessionManager manager;
    private ComponentName component;
    private MediaController controller;
    private boolean started;

    volatile boolean has, playing;
    volatile String title, artist;
    volatile Bitmap art;

    private final MediaSessionManager.OnActiveSessionsChangedListener sessions = this::pick;
    private final MediaController.Callback callback = new MediaController.Callback() {
        @Override
        public void onMetadataChanged(MediaMetadata m) {
            read();
        }

        @Override
        public void onPlaybackStateChanged(PlaybackState s) {
            read();
        }

        @Override
        public void onSessionDestroyed() {
            pick(null);
        }
    };

    MediaWatcher(Context context, Handler handler, Listener listener) {
        this.context = context.getApplicationContext();
        this.handler = handler;
        this.listener = listener;
    }

    /** True when the user gave AnyAuto notification access. */
    static boolean hasAccess(Context c) {
        String on = Settings.Secure.getString(c.getContentResolver(), "enabled_notification_listeners");
        return on != null && on.contains(c.getPackageName());
    }

    void start() {
        if (started) return;
        started = true;
        handler.post(() -> {
            try {
                manager = context.getSystemService(MediaSessionManager.class);
                component = new ComponentName(context, MediaListenerService.class);
                manager.addOnActiveSessionsChangedListener(sessions, component, handler);
                pick(manager.getActiveSessions(component));
            } catch (SecurityException e) {
                Log.i(TAG, "media: no notification access");
                manager = null;
            } catch (RuntimeException e) {
                Log.w(TAG, "media: " + e);
                manager = null;
            }
        });
    }

    void stop() {
        if (!started) return;
        started = false;
        handler.post(() -> {
            try {
                if (manager != null) manager.removeOnActiveSessionsChangedListener(sessions);
            } catch (RuntimeException ignore) {
                // already gone
            }
            if (controller != null) controller.unregisterCallback(callback);
            controller = null;
            manager = null;
        });
    }

    void prev() {
        MediaController c = controller;
        if (c != null) c.getTransportControls().skipToPrevious();
    }

    void next() {
        MediaController c = controller;
        if (c != null) c.getTransportControls().skipToNext();
    }

    void playPause() {
        MediaController c = controller;
        if (c == null) return;
        if (playing) c.getTransportControls().pause();
        else c.getTransportControls().play();
    }

    /** Chooses the session to show: one that is playing, else the first. */
    private void pick(List<MediaController> list) {
        MediaController best = null;
        if (list != null) {
            for (MediaController c : list) {
                PlaybackState s = c.getPlaybackState();
                if (s != null && s.getState() == PlaybackState.STATE_PLAYING) {
                    best = c;
                    break;
                }
                if (best == null) best = c;
            }
        }
        if (controller != null) controller.unregisterCallback(callback);
        controller = best;
        if (best != null) best.registerCallback(callback, handler);
        read();
    }

    private void read() {
        MediaController c = controller;
        if (c == null) {
            has = false;
            playing = false;
            title = artist = null;
            art = null;
        } else {
            MediaMetadata m = c.getMetadata();
            PlaybackState s = c.getPlaybackState();
            has = true;
            playing = s != null && s.getState() == PlaybackState.STATE_PLAYING;
            title = m == null ? null : m.getString(MediaMetadata.METADATA_KEY_TITLE);
            String a = m == null ? null : m.getString(MediaMetadata.METADATA_KEY_ARTIST);
            artist = a != null ? a : m == null ? null : m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST);
            Bitmap b = null;
            if (m != null) {
                b = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_ART);
                if (b == null) b = m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON);
            }
            art = b == null ? null : small(b);
        }
        listener.onMedia();
    }

    private static Bitmap small(Bitmap b) {
        int max = 128;
        if (b.getWidth() <= max && b.getHeight() <= max) return b;
        float k = max / (float) Math.max(b.getWidth(), b.getHeight());
        return Bitmap.createScaledBitmap(b, Math.max(1, Math.round(b.getWidth() * k)),
                Math.max(1, Math.round(b.getHeight() * k)), true);
    }
}
