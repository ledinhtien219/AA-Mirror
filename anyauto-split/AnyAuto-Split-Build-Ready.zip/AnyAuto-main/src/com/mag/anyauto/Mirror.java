package com.mag.anyauto;

import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.RemoteException;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.Surface;

import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;
import java.util.concurrent.atomic.AtomicReferenceArray;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * One screen that shows the virtual display: the car's surface (car/MirrorScreen) or the phone
 * preview. Keeps what should be shown (screen surface, its usable area, the app) and pushes it to
 * {@link DisplayService} whenever it changes or the service (re)connects. All service calls run on
 * one worker thread, in order; input goes through {@link Touch} on the same thread.
 *
 * <p>The display draws into a {@link Compositor}, which puts it into the <b>content rect</b>: the
 * part of the screen surface the user can see. That is the car's stable area (not covered by the
 * action strip, and the dashboard card's slice when AnyAuto is in the map card), else its visible
 * area, else the whole surface. The display is sized to the content rect, and car coordinates
 * are moved into it before they reach {@link Touch}.
 *
 * <p>On the car, AnyAuto's <b>navigation bar</b> (Back, Apps, Keyboard, Close, Hide) takes a band
 * at the left (or, by the setting, the right) of the full-width view, beside the app; taps in it
 * are AnyAuto's, not the app's.
 *
 * <p>Cars without a touch screen (a rotary knob, a touchpad) get the <b>pointer</b>. Their only way
 * into the surface is Android Auto's pan mode: the pan button (which touch screens don't show)
 * turns it on, a nudge of the knob then arrives as a scroll of a fixed distance (75 px on the
 * desktop head unit) and a touchpad as finger distances; turning the knob sends nothing, and a
 * press of the knob just ends pan mode (the car's Back does not). So in pan mode the pointer
 * moves, pushing on against an edge scrolls the app (mouse-wheel events), and the end of pan mode
 * is a tap at the pointer, on the app or on the navigation bar. On the bar the pointer goes from
 * button to button. Pressing the pan button again brings the pointer back where it was.
 *
 * <p>Android Auto doesn't end pan mode when the user goes idle (10 s): it only hides its own
 * buttons, nudges then move the knob's focus instead, and the next press of the pan button ends
 * the pan mode that is still on. So after {@value #PAN_IDLE_MS} ms without the knob the pointer
 * hides, and that press doesn't tap.
 *
 * <p>The display outlives the screen surface: without one (another app in front, the apps grid)
 * it is paused, and the app is still there when the surface comes back. {@link #release()}
 * closes the display; its tasks move back to the phone screen.
 */
public final class Mirror implements Shell.Listener {
    private static final String TAG = "AnyAuto";
    // the car sends the visible and the stable area one after the other: resize once
    private static final long CONTENT_SETTLE_MS = 150;
    // while the car shows AnyAuto: how often to ask whether the phone refused to stay dark
    private static final long FIGHT_CHECK_MS = 10_000;
    // split screen: a grabbed divider lets go after this long without a scroll
    private static final long RESIZE_IDLE_MS = 4000;
    // while dragging, the displays are resized at most this often (and once the drag pauses)
    private static final long RESIZE_SYNC_MS = 250;

    public interface Listener {
        /** Main thread: {@link #problem()} or the navigation bar setting may have changed. */
        void onMirrorChanged();
    }

    /** What the car screen does for the navigation bar (main thread). */
    public interface Nav {
        /** The Apps button: show the apps grid for the focused pane. */
        void apps();

        /** Show the apps grid to choose the app of this slot (a pane's "+"). */
        void pick(int slot);

        /** A short message for the driver (a toast). */
        void message(String text, boolean longer);
    }

    // drives on which the car says that the phone's dark screen is on purpose
    private static final int DARK_TELL_TIMES = 3;

    // the pointer (knob and touchpad cars), sizes in dp: a nudge moves it one step, quick nudges
    // the same way up to POINTER_MAX_SPEED steps; at most a 48 dp touch target apart, so any
    // button can be reached
    private static final float POINTER_STEP_DP = 32;
    private static final int POINTER_MAX_SPEED = 4;
    private static final long POINTER_ACCEL_MS = 600;
    // a knob's nudge: along one axis, at least this far (touchpad finger distances are not)
    private static final float NUDGE_MIN_DP = 30;
    // a touchpad finger pushing this far past an edge scrolls once
    private static final float EDGE_PUSH_DP = 48;
    // an edge push scrolls this share of the app's height (or width)
    private static final float SCROLL_SHARE = 0.45f;
    // a press ends pan mode; wait this long before the tap, so leaving the screen cancels it
    private static final long PAN_CLICK_MS = 150;
    private static final long POINTER_HIDE_MS = 2000;
    // Android Auto's own idle time: after it, the end of pan mode is not a click
    private static final long PAN_IDLE_MS = 10_000;
    // the pointer keeps this far inside the screen, so its dot stays visible
    private static final float POINTER_INSET_DP = 4;
    // drives on which the car explains the pointer
    private static final int POINTER_TELL_TIMES = 3;
    private static final int UP = 0, DOWN = 1, LEFT = 2, RIGHT = 3;

    /** What keeps the app off the screen: a short title and one sentence with the fix. */
    public static final class Problem {
        public final String title, text;

        Problem(String title, String text) {
            this.title = title;
            this.text = text;
        }

        @Override
        public boolean equals(Object o) {
            return o instanceof Problem && ((Problem) o).title.equals(title)
                    && Objects.equals(((Problem) o).text, text);
        }

        @Override
        public int hashCode() {
            return title.hashCode();
        }
    }

    private final HandlerThread thread = new HandlerThread("anyauto-io");
    private final Handler io;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final Listener listener;
    // the car: its surfaces are ours to release (a SurfaceView's are not), and the phone is kept
    // awake with its screen dark while AnyAuto is in use on the car screen (PhonePower)
    private final boolean car;
    private final Touch[] touches = new Touch[2];
    private final Compositor compositor;
    private final Context context;

    // worker thread state
    private Surface screen;           // the car's (or the preview's) surface, or null
    private int screenW, screenH, dpi;
    private final Rect stable = new Rect(), visible = new Rect();
    private Rect forced;              // the preview's simulated dashboard card
    private final Rect content = new Rect();
    private final Rect navBar = new Rect(); // the car's navigation bar, or empty
    private int navSkip;                    // px at its top without buttons (under Android Auto's button)
    private boolean navRight;
    private volatile Nav nav;
    private boolean darkTold;         // this drive was told that the phone's screen is dark on purpose
    private boolean panning;          // Android Auto's pan mode: knob and touchpad move the pointer
    private boolean panTouched;       // a touch-screen tap came during this pan mode: no click at its end
    private boolean panIdle;          // no knob for PAN_IDLE_MS: Android Auto went idle, no click at the end
    private boolean knobFound;        // pan mode showed this drive that the car has a knob or touchpad
    private boolean pointerTold;      // this drive explained the pointer
    private float px = -1, py = -1;   // the pointer in screen-surface pixels (-1: not placed yet)
    private boolean pointerShown;
    private int lastDir = -1, streak;
    private long lastNudge;
    private float pushX, pushY;       // a touchpad finger's distance past the edge
    private boolean hold;             // the car shows AnyAuto's apps grid
    private final ComponentName[] apps = new ComponentName[2]; // what should be on each slot's display
    private IDisplayService pushedTo; // the service the state below belongs to
    private final boolean[] pushedOn = new boolean[2];
    private final int[] pushedW = new int[2], pushedH = new int[2], pushedDpi = new int[2];
    private boolean pushedKeep;
    private Boolean pushedKeyboard;   // keyboard on the display (true) or on the phone (false)
    private Boolean pushedPhoneOn;    // "Keep the phone's screen on"
    private final int[] ids = {-1, -1};
    private final AtomicReferenceArray<ComponentName> launched = new AtomicReferenceArray<>(2);

    // split screen (the car)
    private final Rect[] panes = {new Rect(), new Rect()}; // each slot's pane in the surface; empty = hidden
    private SplitLayout lay;
    private boolean splitOn = true, swapped;
    private float ratio = 0.5f;           // the left pane's share of the width
    private volatile int focus;           // the slot last tapped: gets scrolls, Back and the keyboard
    private boolean homeShown;            // Home: both panes show their "+" until an app is chosen
    private boolean resizing;             // the divider is grabbed: scrolls move it
    private boolean resizeTold;
    private long lastResizeSync;
    private boolean blink;
    private final Runnable endResize = () -> setResizing(false);
    private final Runnable syncNow = this::sync;
    private final Runnable renderBarNow = this::renderBar;
    private final Runnable tick = this::tick;
    private MediaWatcher media;
    private StatusWatcher status;
    private SpeedWatcher speedWatcher;
    private volatile Problem problem;
    private final Runnable applyContent = this::applyContent;
    // a car Mirror has the display right now; the phone preview stays out of its way
    private static volatile Mirror carShowing;
    private static final CopyOnWriteArrayList<Runnable> carListeners = new CopyOnWriteArrayList<>();

    public Mirror(Context context, Listener listener, boolean car) {
        this.context = context.getApplicationContext();
        this.listener = listener;
        this.car = car;
        compositor = new Compositor(this.context);
        thread.start();
        io = new Handler(thread.getLooper());
        touches[0] = new Touch(io, e -> injectSlot(0, e));
        touches[1] = new Touch(io, e -> injectSlot(1, e));
        if (car) {
            splitOn = Prefs.splitOn(this.context);
            ratio = Prefs.splitRatio(this.context);
            swapped = Prefs.swapped(this.context);
            media = new MediaWatcher(this.context, io, this::barChanged);
            status = new StatusWatcher(this.context, io, this::barChanged);
            speedWatcher = new SpeedWatcher(this.context, thread.getLooper(), this::barChanged);
        }
        Shell.addListener(this);
    }

    /** A new or changed screen surface (size or dpi), from the main thread. */
    public void surface(Surface s, int w, int h, int d) {
        io.post(() -> {
            if (screen != s) {
                compositor.detach();
                drop(screen);
            }
            screen = s;
            screenW = w;
            screenH = h;
            dpi = d;
            compositor.attach(s, w, h);
            startWatchers();
            io.removeCallbacks(applyContent);
            applyContent();
        });
    }

    /** The car's visible area (not covered right now) changed. */
    public void visibleArea(Rect r) {
        Rect c = new Rect(r);
        io.post(() -> {
            visible.set(c);
            contentChanged();
        });
    }

    /** The car's stable area (never covered) changed. */
    public void stableArea(Rect r) {
        Rect c = new Rect(r);
        io.post(() -> {
            stable.set(c);
            contentChanged();
        });
    }

    /** The preview's simulated dashboard card (null: the whole surface). */
    void forceContent(Rect r) {
        Rect c = r == null ? null : new Rect(r);
        io.post(() -> {
            forced = c;
            contentChanged();
        });
    }

    /**
     * The surface is going away. Blocks (up to a second) until the display and the compositor
     * have let go of it, because the host may destroy it as soon as this returns.
     */
    public void surfaceGone() {
        for (Touch t : touches) t.cancel();
        CountDownLatch done = new CountDownLatch(1);
        io.post(() -> {
            compositor.detach();
            drop(screen);
            screen = null;
            // the template is gone, and pan mode with it: no tap at the pointer
            panning = false;
            io.removeCallbacks(pointerClick);
            io.removeCallbacks(panIdleNow);
            stopWatchers();
            if (resizing) setResizing(false);
            showPointer(false);
            sync();
            done.countDown();
        });
        try {
            done.await(1, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** The car shows AnyAuto's apps grid: AnyAuto is still in use, keep the phone dark. */
    public void hold(boolean on) {
        io.post(() -> {
            hold = on;
            sync();
        });
    }

    /** Shows this app on the display (starting it there, or moving its task there). */
    public void open(ComponentName c) {
        openIn(0, c);
    }

    /**
     * Shows this app in a slot (0 = first pane, 1 = second): starts it on that slot's display, or
     * moves its task there (so the same app is never in both panes).
     */
    public void openIn(int slot, ComponentName c) {
        int sl = slot == 1 ? 1 : 0;
        io.post(() -> {
            int other = 1 - sl;
            if (c.equals(apps[other])) {
                apps[other] = null;
                launched.set(other, null);
                Prefs.clearLastSlot(context, other);
            }
            apps[sl] = c;
            launched.set(sl, null);
            if (car) {
                homeShown = false;
                focus = sl;
            }
            relayout();
        });
    }

    /** The slot that gets scrolls, Back and the keyboard (the pane last tapped). */
    public int focusSlot() {
        return car ? focus : 0;
    }

    /** The car screen's handler for the navigation bar's Apps button and messages. */
    public void setNav(Nav n) {
        nav = n;
    }

    /** Android Auto's own button: shows or hides the navigation bar. */
    public void toggleNav() {
        Prefs.setNavBar(context, !Prefs.navBar(context));
        io.post(this::applyContent);
        main.post(listener::onMirrorChanged);
    }

    // ---- input in screen-surface coordinates (the car's or the preview's)

    public void click(float x, float y) {
        io.post(() -> {
            // a touch screen as well (some cars have both): its taps aren't the end of pan mode
            if (panning) panTouched = true;
            tap(x, y);
        });
    }

    /** A tap at a point of the screen surface: the navigation bar's, or the app's (worker thread). */
    private void tap(float x, float y) {
        if (car) {
            splitTap(x, y);
            return;
        }
        if (navBar.contains((int) x, (int) y)) navTap(Compositor.navButton(navBar, navSkip, dpi, y));
        else if (content.contains((int) x, (int) y)) touches[0].click(x - content.left, y - content.top);
    }

    /**
     * Android Auto's pan mode came on or went off (main thread). Only cars without a touch screen
     * show the pan button, so this is the knob's or touchpad's way in: on, the pointer shows; off,
     * which is how a press of the knob arrives, it taps where the pointer is.
     */
    public void panMode(boolean on) {
        io.post(() -> {
            if (on == panning) return;
            panning = on;
            io.removeCallbacks(hidePointer);
            io.removeCallbacks(pointerClick);
            io.removeCallbacks(panIdleNow);
            if (on) {
                panTouched = false;
                panActive();
                pushX = pushY = 0;
                lastDir = -1;
                if (!Prefs.carKnob(context)) {
                    Prefs.setCarKnob(context);
                    knobFound = true;
                }
                showPointer(true);
                tellPointer();
            } else {
                if (!panTouched && !panIdle) io.postDelayed(pointerClick, PAN_CLICK_MS);
                else Log.d(TAG, "pan mode ended without a click (" + (panIdle ? "idle" : "touch") + ")");
                io.postDelayed(hidePointer, POINTER_HIDE_MS);
                // the action strip gets Apps; refreshed only now, so pan mode isn't disturbed
                if (knobFound) {
                    knobFound = false;
                    main.post(listener::onMirrorChanged);
                }
            }
        });
    }

    private final Runnable pointerClick = this::pointerClick;
    private final Runnable hidePointer = this::hidePointer;
    private final Runnable panIdleNow = this::panIdleNow;

    /** The knob was used in pan mode: the pointer is live (again) for PAN_IDLE_MS. */
    private void panActive() {
        io.removeCallbacks(panIdleNow);
        io.postDelayed(panIdleNow, PAN_IDLE_MS);
        if (panIdle) {
            panIdle = false;
            showPointer(true);
        }
    }

    /** Android Auto went idle: its pan mode is dead until the pan button is pressed again. */
    private void panIdleNow() {
        if (!panning) return;
        panIdle = true;
        showPointer(false);
    }

    /** The end of pan mode: a tap where the pointer is, unless the screen went away meanwhile. */
    private void pointerClick() {
        if (screen == null || px < 0) return;
        Log.d(TAG, "pointer click " + Math.round(px) + "," + Math.round(py));
        compositor.cursorPressed();
        tap(px, py);
    }

    private void hidePointer() {
        if (!panning) showPointer(false);
    }

    /** Shows or hides the pointer, placing it first: in the middle the first time, else where it was. */
    private void showPointer(boolean on) {
        pointerShown = on;
        if (on) placePointer();
        if (px >= 0) compositor.cursor(px, py, on);
    }

    /** The pointer goes over the app and the navigation bar, a little inside the screen's edges. */
    private Rect pointerArea() {
        Rect r = new Rect(content);
        if (!navBar.isEmpty()) r.union(navBar);
        int in = Math.round(POINTER_INSET_DP * dpi / 160f);
        if (r.width() > 4 * in && r.height() > 4 * in) {
            r.inset(r.left <= 0 ? in : 0, r.top <= 0 ? in : 0);
            if (r.right >= screenW) r.right -= in;
            if (r.bottom >= screenH) r.bottom -= in;
        }
        return r;
    }

    private void placePointer() {
        Rect a = pointerArea();
        if (a.isEmpty()) return;
        if (px < 0) {
            px = content.exactCenterX();
            py = content.exactCenterY();
        }
        px = clamp(px, a.left, a.right - 1);
        py = clamp(py, a.top, a.bottom - 1);
    }

    /**
     * Pan mode's scroll (worker thread). The distances point the way the knob was pushed (the
     * opposite of a finger drag's). A knob's nudge moves the pointer by a step; quick nudges the
     * same way take bigger steps. A touchpad's finger distances move it as they are. Pushing on
     * against an edge scrolls the app instead.
     */
    private void movePointer(float dx, float dy) {
        Rect a = pointerArea();
        if (a.isEmpty()) return;
        panActive();
        placePointer();
        float s = dpi / 160f;
        boolean nudge = (dx == 0) != (dy == 0) && Math.max(Math.abs(dx), Math.abs(dy)) >= NUDGE_MIN_DP * s;
        if (nudge) {
            int dir = dx > 0 ? RIGHT : dx < 0 ? LEFT : dy > 0 ? DOWN : UP;
            long now = SystemClock.uptimeMillis();
            streak = dir == lastDir && now - lastNudge < POINTER_ACCEL_MS ? Math.min(streak + 1, POINTER_MAX_SPEED - 1) : 0;
            lastDir = dir;
            lastNudge = now;
            if (!navBar.isEmpty() && navNudge(dir, POINTER_STEP_DP * s * (1 + streak), a)) {
                compositor.cursor(px, py, true);
                return;
            }
            boolean atEdge = dir == RIGHT ? px >= a.right - 1 : dir == LEFT ? px <= a.left
                    : dir == DOWN ? py >= a.bottom - 1 : py <= a.top;
            if (atEdge) {
                edgeScroll(dir);
                return;
            }
            float step = POINTER_STEP_DP * s * (1 + streak);
            px = clamp(px + Math.signum(dx) * step, a.left, a.right - 1);
            py = clamp(py + Math.signum(dy) * step, a.top, a.bottom - 1);
        } else {
            float nx = px + dx, ny = py + dy;
            px = clamp(nx, a.left, a.right - 1);
            py = clamp(ny, a.top, a.bottom - 1);
            pushX = nx != px ? pushX + nx - px : 0;
            pushY = ny != py ? pushY + ny - py : 0;
            float limit = EDGE_PUSH_DP * s;
            if (Math.abs(pushY) >= limit) {
                edgeScroll(pushY > 0 ? DOWN : UP);
                pushY = 0;
            }
            if (Math.abs(pushX) >= limit) {
                edgeScroll(pushX > 0 ? RIGHT : LEFT);
                pushX = 0;
            }
        }
        compositor.cursor(px, py, true);
    }

    /**
     * A knob's nudge where the navigation bar is (worker thread): on the bar the pointer sits on a
     * button, up and down go to the next one, towards the app leaves the bar (towards the screen's
     * edge does nothing); a nudge that would end on the bar lands on the button at that height.
     * False when the bar has nothing to do with this nudge.
     */
    private boolean navNudge(int dir, float step, Rect a) {
        int n = Compositor.navCount();
        boolean onBar = navBar.contains((int) px, (int) py);
        if (onBar) {
            int i = navButtonNear(py);
            if (dir == UP || dir == DOWN) {
                i = Math.max(0, Math.min(n - 1, i + (dir == DOWN ? 1 : -1)));
                py = Compositor.navCentreY(navBar, navSkip, dpi, i);
            } else if (navRight ? dir == LEFT : dir == RIGHT) {
                px = clamp(navRight ? navBar.left - step : navBar.right + step, a.left, a.right - 1);
            }
            return true;
        }
        if (dir != (navRight ? RIGHT : LEFT)) return false;
        float nx = px + (navRight ? step : -step);
        if (navRight ? nx < navBar.left : nx >= navBar.right) return false;
        px = navBar.exactCenterX();
        py = Compositor.navCentreY(navBar, navSkip, dpi, navButtonNear(py));
        return true;
    }

    /** The bar's button at this height, or the nearest one above or below the buttons. */
    private int navButtonNear(float y) {
        int i = Compositor.navButton(navBar, navSkip, dpi, y);
        if (i >= 0) return i;
        return y < Compositor.navCentreY(navBar, navSkip, dpi, 0) ? 0 : Compositor.navCount() - 1;
    }

    /**
     * Scrolls the app by about half a screen with the mouse wheel: up or down at the pointer's x and
     * the app's middle height (so a bar at the very top or bottom doesn't catch it), left or right
     * at the pointer's y and the middle width.
     */
    private void edgeScroll(int dir) {
        // the pane under the pointer (the phone preview has only the one)
        int sl = car ? (lay == null ? -1 : lay.slotAt((int) px, (int) py)) : 0;
        if (sl < 0 || panes[sl].isEmpty()) return;
        Rect cr = panes[sl];
        boolean vertical = dir == UP || dir == DOWN;
        float notch = 64f * dpi / 160f;
        int n = Math.max(1, Math.round(SCROLL_SHARE * (vertical ? cr.height() : cr.width()) / notch));
        float x = vertical ? clamp(px, cr.left, cr.right - 1) : cr.exactCenterX();
        float y = vertical ? cr.exactCenterY() : clamp(py, cr.top, cr.bottom - 1);
        float v = dir == DOWN ? -n : dir == UP ? n : 0;
        float h = dir == RIGHT ? n : dir == LEFT ? -n : 0;
        Log.d(TAG, "pointer scroll " + (vertical ? "v " + v : "h " + h));
        injectSlot(sl, Touch.wheel(x - cr.left, y - cr.top, v, h));
    }

    private static float clamp(float v, float lo, float hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    /** The first few drives with pan mode: how the pointer works, once per drive. */
    private void tellPointer() {
        if (pointerTold || Prefs.pointerTold(context) >= POINTER_TELL_TIMES) return;
        pointerTold = true;
        Prefs.addPointerTold(context);
        say("Move the ring, then press to click there. Push past an edge to scroll.", true);
    }

    /** A tap on the navigation bar (worker thread). All but Apps need an open app. */
    private void navTap(int button) {
        if (button < 0) return;
        boolean open = launched.get(0) != null;
        if (!open && button != Compositor.NAV_APPS) return;
        compositor.navPressed(button);
        // like a finger on the app: wakes the phone again if the user had put it to sleep
        if (car && pushedKeep) call(s -> s.keepRunning(true));
        switch (button) {
            case Compositor.NAV_BACK:
                call(s -> s.key(KeyEvent.KEYCODE_BACK));
                break;
            case Compositor.NAV_APPS:
                main.post(() -> {
                    Nav n = nav;
                    if (n != null) n.apps();
                });
                break;
            case Compositor.NAV_KEYBOARD:
                toggleKeyboard(r -> say(keyboardMessage(r), false));
                break;
            case Compositor.NAV_CLOSE:
                closeApp();
                break;
            case Compositor.NAV_HIDE:
                Prefs.setNavBar(context, false);
                applyContent();
                main.post(listener::onMirrorChanged);
                break;
        }
    }

    /**
     * Closes the app on the display (its tasks are removed, as a swipe in Recents does) and
     * leaves the display empty; the next drive starts at the apps grid.
     */
    public void closeApp() {
        io.post(() -> {
            int sl = car ? focus : 0;
            ComponentName was = launched.get(sl);
            String[] r = {null};
            call(s -> r[0] = s.closeAppSlot(sl));
            Log.i(TAG, "close " + (was == null ? "-" : was.flattenToShortString()) + ": " + r[0]);
            if (r[0] == null) return; // no service: nothing is shown anyway
            if (!"ok".equals(r[0]) && !"none".equals(r[0])) {
                say("Can't close the app: " + (r[0].startsWith("close: ") ? r[0].substring(7) : r[0]), false);
                return;
            }
            apps[sl] = null;
            launched.set(sl, null);
            Prefs.clearLastSlot(context, sl);
            relayout();
            main.post(listener::onMirrorChanged);
        });
    }

    private void say(String text, boolean longer) {
        if (text == null) return;
        main.post(() -> {
            Nav n = nav;
            if (n != null) n.message(text, longer);
        });
    }

    /** A drag's distances; in pan mode, the knob's or touchpad's (they move the pointer). */
    public void scroll(float dx, float dy) {
        io.post(() -> {
            // a grabbed divider takes the drag (a finger's distances are minus its movement, a
            // knob's nudge is the way it was pushed)
            if (car && resizing) {
                resizeBy(panning ? dx : -dx);
                return;
            }
            if (panning) {
                movePointer(dx, dy);
                return;
            }
            int sl = car ? focus : 0;
            if (canTouch(sl)) touches[sl].scroll(dx, dy);
        });
    }

    public void fling(float vx, float vy) {
        io.post(() -> {
            if (panning || (car && resizing)) return;
            int sl = car ? focus : 0;
            if (canTouch(sl)) touches[sl].fling(vx, vy);
        });
    }

    public void scale(float fx, float fy, float factor) {
        io.post(() -> {
            if (car && resizing) return;
            float x = fx, y = fy;
            if (x < 0 || y < 0) {
                // no focal point (the car has no touch screen): the pointer's, or the focused pane's middle
                if (panning && px >= 0) {
                    x = px;
                    y = py;
                } else {
                    Rect f = panes[car ? focus : 0].isEmpty() ? content : panes[car ? focus : 0];
                    x = f.exactCenterX();
                    y = f.exactCenterY();
                }
            }
            int sl = car && lay != null ? lay.slotAt((int) x, (int) y) : 0;
            if (sl < 0) sl = focus;
            if (canTouch(sl)) touches[sl].scale(x - panes[sl].left, y - panes[sl].top, factor);
        });
    }

    /** A pane that shows an app on a display that exists: touches can go there. */
    private boolean canTouch(int slot) {
        return ids[slot] >= 0 && !panes[slot].isEmpty() && !(car && isEmpty(slot));
    }

    /** A real touch, passed through as it is (the preview's "Direct" mode). */
    void raw(MotionEvent e) {
        MotionEvent copy = MotionEvent.obtain(e);
        copy.setSource(android.view.InputDevice.SOURCE_TOUCHSCREEN);
        io.post(() -> {
            copy.offsetLocation(-panes[0].left, -panes[0].top);
            injectSlot(0, copy);
        });
    }

    /**
     * The keyboard button (car action strip, preview rail). {@code done} gets the service's
     * answer on the main thread; {@link #keyboardMessage} turns it into a short message.
     */
    public void toggleKeyboard(java.util.function.Consumer<String> done) {
        io.post(() -> {
            String[] r = {"error: no display"};
            int sl = car ? focus : 0;
            call(s -> r[0] = s.toggleKeyboardSlot(sl));
            main.post(() -> done.accept(r[0]));
        });
    }

    /** A short message for the keyboard button's answer, or null when the screen says enough. */
    public static String keyboardMessage(String r) {
        if (r == null) return null;
        switch (r) {
            case "shown":
            case "hidden":
                return null;
            case "no field":
                return "Tap a text field first";
            case "old android":
                return "The keyboard button needs Android 11 or newer";
            default:
                return "Keyboard: " + (r.startsWith("error: ") ? r.substring(7) : r);
        }
    }

    /** A setting changed (keyboard, full screen, phone screen): the car's Mirror applies it now. */
    public static void settingsChanged() {
        Mirror m = carShowing;
        if (m != null) m.io.post(m::applyContent);
    }

    /** The app's Back (the car's Back button, the preview's rail). */
    public void back() {
        io.post(() -> {
            // like a finger on the app: wakes the phone again if the user had put it to sleep
            if (car && pushedKeep) call(s -> s.keepRunning(true));
            int sl = car ? focus : 0;
            call(s -> s.keySlot(sl, KeyEvent.KEYCODE_BACK));
        });
    }

    /** Closes the display and stops the worker. */
    public void release() {
        Shell.removeListener(this);
        if (carShowing == this) setCarShowing(null);
        io.post(() -> {
            for (Touch t : touches) t.cancel();
            stopWatchers();
            io.removeCallbacks(endResize);
            IDisplayService s = pushedTo;
            if (s != null) {
                try {
                    s.close();
                } catch (RemoteException ignore) {
                    // the service is gone, and the display with it
                }
            }
            compositor.detach();
            compositor.release();
            if (speedWatcher != null) speedWatcher.release();
            drop(screen);
            screen = null;
            thread.quitSafely();
        });
    }

    /** Stops the worker without touching the display (a preview that never used it). */
    public void releaseQuietly() {
        Shell.removeListener(this);
        compositor.release();
        thread.quitSafely();
    }

    /** True while AnyAuto is on the car screen: the one display is the car's then. */
    public static boolean carShowing() {
        return carShowing != null;
    }

    /** Called on the main thread whenever {@link #carShowing()} changes. */
    public static void addCarListener(Runnable r) {
        carListeners.addIfAbsent(r);
    }

    public static void removeCarListener(Runnable r) {
        carListeners.remove(r);
    }

    private static void setCarShowing(Mirror m) {
        if (carShowing == m) return;
        carShowing = m;
        new Handler(Looper.getMainLooper()).post(() -> {
            for (Runnable r : carListeners) r.run();
        });
    }

    /** What keeps the app off the screen; null when it is shown. */
    public Problem problem() {
        return problem;
    }

    /** The app on the display now, or null. */
    public ComponentName currentApp() {
        return launched.get(car ? focus : 0);
    }

    /** The app on this slot's display, or null. */
    public ComponentName currentApp(int slot) {
        return launched.get(slot == 1 ? 1 : 0);
    }

    @Override
    public void onShellChanged() {
        io.post(this::sync);
    }

    /** A touch on a slot's display, in that display's pixels (takes the event and recycles it). */
    private void injectSlot(int slot, MotionEvent e) {
        IDisplayService s = pushedTo;
        if (s == null || ids[slot] < 0) {
            e.recycle();
            return;
        }
        try {
            // a finger on the car screen wakes the phone again if the user had put it to sleep
            if (car && e.getActionMasked() == MotionEvent.ACTION_DOWN) s.keepRunning(true);
            s.touchSlot(slot, e);
        } catch (RemoteException ex) {
            lost(s);
        } finally {
            e.recycle();
        }
    }

    // ------------------------------------------------------------------ worker thread

    /** The navigation bar may come or go: lay out again, or just sync before the first surface. */
    private void relayout() {
        if (screenW > 0 && screenH > 0) applyContent();
        else sync();
    }

    private void contentChanged() {
        io.removeCallbacks(applyContent);
        io.postDelayed(applyContent, CONTENT_SETTLE_MS);
    }

    /** Stable area, else visible area, else the whole surface (an area must fit the surface). */
    private void applyContent() {
        Rect full = new Rect(0, 0, screenW, screenH);
        Rect r;
        if (forced != null && full.contains(forced) && !forced.isEmpty()) r = forced;
        else if (!stable.isEmpty() && full.contains(stable)) r = stable;
        else if (!visible.isEmpty() && full.contains(visible)) r = visible;
        else r = full;
        if (r.isEmpty()) return;
        if (car) {
            // the split screen lays itself out inside the area the car leaves visible
            applySplit(r, true);
            return;
        }
        // the phone preview: one pane, the whole area
        panes[0].set(r);
        panes[1].setEmpty();
        if (!r.equals(content)) {
            content.set(r);
            Log.i(TAG, "content " + content.toShortString() + " of " + screenW + "x" + screenH);
            compositor.content(content, dpi);
            touches[0].area(content.width(), content.height(), dpi, null);
        }
        if (px >= 0) showPointer(pointerShown);
        sync();
    }

    // ------------------------------------------------------------------ split screen (worker thread)

    private boolean isEmpty(int slot) {
        return apps[slot] == null || homeShown;
    }

    /** Lays out the top bar and the panes inside r, tells the compositor, and optionally syncs the displays. */
    private void applySplit(Rect r, boolean doSync) {
        content.set(r);
        lay = SplitLayout.compute(r, dpi, splitOn, ratio, swapped, focus);
        for (int i = 0; i < 2; i++) {
            Rect p = lay.pane[i];
            boolean resized = p.width() != panes[i].width() || p.height() != panes[i].height();
            panes[i].set(p);
            if (resized && !p.isEmpty()) touches[i].area(p.width(), p.height(), dpi, null);
        }
        Log.i(TAG, "split " + (lay.split ? "on" : "off") + " panes " + panes[0].toShortString() + " "
                + panes[1].toShortString() + " of " + screenW + "x" + screenH);
        pushScene();
        renderBar();
        if (px >= 0) showPointer(pointerShown);
        if (doSync) sync();
    }

    private void pushScene() {
        if (lay != null) compositor.scene(lay, isEmpty(0), isEmpty(1), resizing, focus, dpi);
    }

    /** A tap on the car screen (worker thread): the top bar, the divider, or a pane. */
    private void splitTap(float x, float y) {
        SplitLayout l = lay;
        if (l == null) return;
        int xi = (int) x, yi = (int) y;
        if (l.bar.contains(xi, yi)) {
            barTap(TopBar.hit(l.bar.width(), l.bar.height(), x - l.bar.left, y - l.bar.top));
            return;
        }
        if (l.split && l.grab.contains(xi, yi)) {
            setResizing(!resizing);
            return;
        }
        if (resizing) setResizing(false);
        int slot = l.slotAt(xi, yi);
        if (slot < 0) return;
        if (focus != slot) {
            focus = slot;
            pushScene();
        }
        if (isEmpty(slot)) {
            main.post(() -> {
                Nav n = nav;
                if (n != null) n.pick(slot);
            });
        } else {
            touches[slot].click(x - l.pane[slot].left, y - l.pane[slot].top);
        }
    }

    private void barTap(int button) {
        if (button < 0) return;
        if (resizing) setResizing(false);
        // like a finger on an app: wakes the phone again if the user had put it to sleep
        if (pushedKeep) call(s -> s.keepRunning(true));
        switch (button) {
            case TopBar.HOME:
                homeShown = true;
                pushScene();
                break;
            case TopBar.APPS:
                main.post(() -> {
                    Nav n = nav;
                    if (n != null) n.pick(focus);
                });
                break;
            case TopBar.PREV:
            case TopBar.PLAY:
            case TopBar.NEXT:
                if (!media.has) {
                    if (!MediaWatcher.hasAccess(context)) {
                        say("Mở AnyAuto trên điện thoại và cấp quyền truy cập thông báo để điều khiển nhạc", true);
                    }
                    break;
                }
                if (button == TopBar.PREV) media.prev();
                else if (button == TopBar.NEXT) media.next();
                else media.playPause();
                break;
            case TopBar.SWAP:
                if (lay != null && lay.split) {
                    swapped = !swapped;
                    Prefs.setSwapped(context, swapped);
                } else {
                    focus = 1 - focus; // one pane: show the other app
                }
                applySplit(content, true);
                break;
            case TopBar.SPLIT:
                splitOn = !splitOn;
                Prefs.setSplitOn(context, splitOn);
                applySplit(content, true);
                break;
            default:
                break;
        }
    }

    /** The divider was tapped: scrolls now move it, until a tap elsewhere or a few seconds' pause. */
    private void setResizing(boolean on) {
        if (on == resizing) return;
        resizing = on;
        io.removeCallbacks(endResize);
        if (on) {
            io.postDelayed(endResize, RESIZE_IDLE_MS);
            if (!resizeTold) {
                resizeTold = true;
                say("Vuốt trái/phải để đổi kích thước. Chạm ra ngoài để xong.", false);
            }
            pushScene();
        } else {
            Prefs.setSplitRatio(context, ratio);
            pushScene();
            sync();
        }
    }

    /** Moves the divider by dx px (positive = right). The displays follow while the drag goes on. */
    private void resizeBy(float dx) {
        SplitLayout l = lay;
        if (l == null || !l.split) return;
        int total = l.area.width() - l.gap;
        if (total <= 0) return;
        ratio = Math.max(SplitLayout.MIN_RATIO, Math.min(SplitLayout.MAX_RATIO, ratio + dx / total));
        io.removeCallbacks(endResize);
        io.postDelayed(endResize, RESIZE_IDLE_MS);
        applySplit(content, false);
        long now = SystemClock.uptimeMillis();
        io.removeCallbacks(syncNow);
        if (now - lastResizeSync > RESIZE_SYNC_MS) {
            lastResizeSync = now;
            sync();
        } else {
            io.postDelayed(syncNow, 120);
        }
    }

    // ---- the top bar's live parts

    private void startWatchers() {
        if (!car) return;
        media.start();
        status.start();
        speedWatcher.start();
        io.removeCallbacks(tick);
        io.post(tick);
    }

    private void stopWatchers() {
        if (!car) return;
        io.removeCallbacks(tick);
        media.stop();
        status.stop();
        speedWatcher.stop();
    }

    private void barChanged() {
        io.removeCallbacks(renderBarNow);
        io.post(renderBarNow);
    }

    /** Once a minute (the clock), and while the car is over the limit, twice a second (the sign blinks). */
    private void tick() {
        boolean over = speedWatcher.limit > 0 && speedWatcher.speed > speedWatcher.limit;
        blink = over && !blink;
        status.refresh();
        renderBar();
        long delay = 60_000 - System.currentTimeMillis() % 60_000 + 50;
        if (over) delay = Math.min(delay, 600);
        io.postDelayed(tick, delay);
    }

    private static final String[] WEEKDAY = {"CN", "T2", "T3", "T4", "T5", "T6", "T7"};

    private void renderBar() {
        SplitLayout l = lay;
        if (!car || l == null || l.bar.isEmpty() || screen == null) return;
        TopBar.State st = new TopBar.State();
        Calendar c = Calendar.getInstance();
        st.time = String.format(Locale.US, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE));
        st.date = WEEKDAY[c.get(Calendar.DAY_OF_WEEK) - 1]
                + String.format(Locale.US, " %02d/%02d", c.get(Calendar.DAY_OF_MONTH), c.get(Calendar.MONTH) + 1);
        st.hasMedia = media.has;
        st.playing = media.playing;
        st.title = media.title;
        st.artist = media.artist;
        st.art = media.art;
        st.speed = speedWatcher.speed;
        st.limit = speedWatcher.limit;
        st.over = st.limit > 0 && st.speed > st.limit;
        st.blink = blink;
        st.wifi = status.wifi;
        st.bt = status.bt;
        st.bars = status.bars;
        st.split = l.split;
        compositor.bar(TopBar.render(l.bar.width(), l.bar.height(), st));
    }

    /**
     * The setting "Full screen in the car": the app gets the whole surface, edge to edge, the way
     * Google Maps draws its map. The stable area leaves a margin all round (12 px on the desktop
     * head unit, plus the band Android Auto keeps for Apps and Back), which showed as a black frame.
     * The buttons float over the app while shown and hide by themselves, and Android Auto rounds the
     * surface's corners. Fixed, so the app never jumps when the buttons show and hide. Only for
     * the full-width view: the dashboard and launcher cards keep their card.
     */
    private Rect fullScreen(Rect s) {
        if (s.width() < screenW * 0.8f) return s;
        return new Rect(0, 0, screenW, screenH);
    }

    /**
     * The flicker guard's memory (PhonePower): a phone that would not stay dark keeps its screen
     * on in later drives too, by turning on "Keep the phone's screen on" (the user can turn it off
     * again in the menu). Asked every FIGHT_CHECK_MS while the car shows AnyAuto.
     */
    private final Runnable checkFights = this::checkFights;

    private void checkFights() {
        IDisplayService s = pushedTo;
        if (s == null || !car || !pushedKeep) return;
        try {
            if (s.phoneScreenFights()) {
                if (!Prefs.keepPhoneOn(context)) {
                    Prefs.setKeepPhoneOn(context, true);
                    Log.i(TAG, "the phone does not stay dark: Keep the phone's screen on is now on");
                    applyContent(); // pushes the setting
                }
                return;
            }
        } catch (RemoteException e) {
            lost(s);
            return;
        }
        io.postDelayed(checkFights, FIGHT_CHECK_MS);
    }

    private void sync() {
        IDisplayService s = Shell.service();
        if (s == null) {
            pushedTo = null;
            ids[0] = ids[1] = -1;
            setProblem(shellProblem(Shell.state()));
            return;
        }
        if (s != pushedTo) {
            // a new service process: nothing of ours is on it yet
            pushedTo = s;
            pushedKeep = false;
            pushedKeyboard = null;
            pushedPhoneOn = null;
            for (int i = 0; i < 2; i++) {
                pushedOn[i] = false;
                ids[i] = -1;
                launched.set(i, null);
            }
        }
        try {
            if (content.isEmpty()) {
                setProblem(null); // no surface yet
                return;
            }
            boolean on = screen != null;
            for (int slot = 0; slot < (car ? 2 : 1); slot++) {
                // the second display is only made once an app is meant for it
                if (slot == 1 && ids[1] < 0 && apps[1] == null) continue;
                Rect pane = panes[slot];
                boolean shown = on && !pane.isEmpty();
                int w = !pane.isEmpty() ? pane.width() : pushedW[slot] > 0 ? pushedW[slot] : Math.max(2, content.width() / 2);
                int h = !pane.isEmpty() ? pane.height() : pushedH[slot] > 0 ? pushedH[slot] : Math.max(2, content.height() / 2);
                if (ids[slot] < 0 || shown != pushedOn[slot] || w != pushedW[slot] || h != pushedH[slot]
                        || dpi != pushedDpi[slot]) {
                    // a hidden pane (or no screen) gets no surface: its display pauses instead of drawing for nobody
                    ids[slot] = s.showSlot(slot, shown ? compositor.input(slot) : null, w, h, dpi);
                    pushedOn[slot] = shown;
                    pushedW[slot] = w;
                    pushedH[slot] = h;
                    pushedDpi[slot] = dpi;
                    if (ids[slot] < 0) {
                        setProblem(Shell.rootOnOldAndroid()
                                ? new Problem("Shizuku runs as root",
                                        "On Android 13 and older, start Shizuku with Wireless debugging instead.")
                                : new Problem("Can't make the car display", s.lastError()));
                        return;
                    }
                    pushedKeyboard = null; // a new display, or a new size: say it again
                    if (slot == 0) {
                        Log.i(TAG, s.info());
                        // for the phone's Home screen: does this phone's screen go dark in the car?
                        Prefs.setPhoneGroup(context, s.phoneGroup());
                    }
                }
            }
            // the car: where the setting says; the preview: on the phone, since a finger on the
            // phone takes the focus and would close a keyboard on the display (DisplayService)
            Boolean keyboard = car && Prefs.keyboardOnCar(context);
            if (!keyboard.equals(pushedKeyboard)) {
                s.keyboardHere(keyboard);
                pushedKeyboard = keyboard;
            }
            Boolean phoneOn = car && Prefs.keepPhoneOn(context);
            if (!phoneOn.equals(pushedPhoneOn)) {
                s.phoneScreenOn(phoneOn);
                pushedPhoneOn = phoneOn;
            }
            boolean keep = screen != null || hold;
            if (car && pushedKeep != keep) {
                pushedKeep = keep;
                s.keepRunning(keep);
                if (keep) setCarShowing(this);
                else if (carShowing == this) setCarShowing(null);
                io.removeCallbacks(checkFights);
                if (keep) io.postDelayed(checkFights, FIGHT_CHECK_MS);
                if (keep) tellDark(s);
            }
            for (int slot = 0; slot < 2; slot++) {
                ComponentName a = apps[slot];
                if (a == null || ids[slot] < 0 || a.equals(launched.get(slot))) continue;
                String r = s.launchSlot(slot, a);
                if (!"ok".equals(r)) {
                    setProblem(new Problem("Can't open " + label(a), r + ". Try again from Apps."));
                    return;
                }
                launched.set(slot, a);
                Log.i(TAG, "opened " + a.flattenToShortString() + " on display " + ids[slot] + " (slot " + slot + ")");
            }
            setProblem(null);
        } catch (DeadObjectException e) {
            lost(s);
        } catch (RemoteException e) {
            setProblem(new Problem("Can't reach the display service", String.valueOf(e)));
        }
    }

    /**
     * The first few drives: the car says that the phone's dark screen is on purpose, once per
     * drive, when this phone's screen does go dark (it shares the car display's group, and no
     * setting keeps it on). New users otherwise take the black phone for a crash.
     */
    private void tellDark(IDisplayService s) throws RemoteException {
        if (darkTold || Prefs.darkTold(context) >= DARK_TELL_TIMES) return;
        if (s.phoneGroup() != 1 || Prefs.keepPhoneOn(context) || !Prefs.keyboardOnCar(context)) return;
        darkTold = true;
        Prefs.addDarkTold(context);
        say("Your phone's screen is off on purpose while AnyAuto runs. It comes back when you leave AnyAuto.", true);
    }

    private String label(ComponentName c) {
        try {
            PackageManager pm = context.getPackageManager();
            return String.valueOf(pm.getActivityInfo(c, 0).loadLabel(pm));
        } catch (PackageManager.NameNotFoundException e) {
            return c.getPackageName();
        }
    }

    private interface Call {
        void call(IDisplayService s) throws RemoteException;
    }

    private void call(Call c) {
        IDisplayService s = pushedTo;
        if (s == null || (ids[0] < 0 && ids[1] < 0)) return;
        try {
            c.call(s);
        } catch (RemoteException e) {
            lost(s);
        }
    }

    private void lost(IDisplayService s) {
        Log.w(TAG, "display service died");
        pushedTo = null;
        ids[0] = ids[1] = -1;
        Shell.lost(s);
        setProblem(shellProblem(Shell.state()));
    }

    private void drop(Surface s) {
        if (s != null && car) s.release();
    }

    private void setProblem(Problem p) {
        updateOverlay(p);
        if (Objects.equals(p, problem)) return;
        problem = p;
        if (p != null) Log.i(TAG, "car screen: " + p.title + " (" + p.text + ")");
        main.post(listener::onMirrorChanged);
    }

    /** What the surface shows when there is no app frame. */
    private void updateOverlay(Problem p) {
        if (p != null) {
            // the car shows the text in its own message box; the phone preview has only this
            compositor.overlay(Compositor.PROBLEM, p.title, car ? null : p.text);
        } else if (pushedTo == null && Shell.state() == Shell.State.CONNECTING) {
            compositor.overlay(Compositor.CONNECTING, "Connecting to Shizuku…", null);
        } else if (!car && apps[0] == null) {
            compositor.overlay(Compositor.IDLE, "No app open", null);
        } else {
            compositor.overlay(Compositor.NONE, null, null);
        }
    }

    /** The car's and the phone's wording for a Shizuku state (no problem while connecting). */
    static Problem shellProblem(Shell.State st) {
        switch (st) {
            case NO_SHIZUKU:
                return new Problem("Shizuku isn't installed", "Install Shizuku on the phone, then start it.");
            case NOT_RUNNING:
                return new Problem("Shizuku isn't running", "Start it in the Shizuku app on the phone.");
            case OLD_SHIZUKU:
                return new Problem("Shizuku is too old", "Update Shizuku on the phone.");
            case NO_PERMISSION:
                return new Problem("AnyAuto isn't allowed in Shizuku", "Open AnyAuto on the phone and tap Allow.");
            default:
                return null;
        }
    }
}
