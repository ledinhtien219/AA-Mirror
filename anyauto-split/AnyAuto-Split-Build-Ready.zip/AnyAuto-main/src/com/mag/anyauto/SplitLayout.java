package com.mag.anyauto;

import android.graphics.Rect;

/**
 * Where everything goes on the car screen in split mode (screen-surface pixels): the top bar, the
 * two panes (one per app slot) and the divider between them. Built by {@link #compute}, then only
 * read, so it can be handed to the GL thread as it is.
 *
 * <p>{@link #ratio} is the share of the width the <b>left</b> pane gets, whichever slot it shows;
 * swapping the two apps only changes which slot is on the left.
 */
final class SplitLayout {
    static final float MIN_RATIO = 0.25f, MAX_RATIO = 0.75f;

    /** The top bar. */
    final Rect bar = new Rect();
    /** Where each slot's app is drawn; empty = that slot is not shown. */
    final Rect[] pane = {new Rect(), new Rect()};
    /** Everything under the bar: both panes and the gap between them. */
    final Rect area = new Rect();
    /** The divider's handle as drawn, and the wider strip where a tap grabs it. */
    final Rect handle = new Rect(), grab = new Rect();
    /** Two panes shown (false: one pane fills the area). */
    boolean split;
    int gap, margin;

    static int margin(int dpi) {
        return Math.round(8 * dpi / 160f);
    }

    static int barHeight(int dpi) {
        return Math.round(56 * dpi / 160f);
    }

    /**
     * @param c       the part of the surface the user sees
     * @param split   two panes (true) or only the {@code focus} slot's (false)
     * @param ratio   the left pane's share of the width
     * @param swapped slot 1 on the left, slot 0 on the right
     */
    static SplitLayout compute(Rect c, int dpi, boolean split, float ratio, boolean swapped, int focus) {
        SplitLayout l = new SplitLayout();
        int m = margin(dpi), g = m, bh = barHeight(dpi);
        l.margin = m;
        l.gap = g;
        int left = c.left + m, right = c.right - m, top = c.top + m, bottom = c.bottom - m;
        l.bar.set(left, top, right, top + bh);
        int top2 = l.bar.bottom + m;
        l.area.set(left, top2, right, Math.max(top2 + 1, bottom));
        int f = focus == 1 ? 1 : 0;
        int total = right - left - g;
        int min = Math.round(120 * dpi / 160f);
        if (!split || total < 2 * min) {
            l.split = false;
            l.pane[f].set(l.area);
            return l;
        }
        l.split = true;
        float r = Math.max(MIN_RATIO, Math.min(MAX_RATIO, ratio));
        int lw = Math.max(min, Math.min(total - min, Math.round(total * r)));
        Rect a = new Rect(left, top2, left + lw, l.area.bottom);
        Rect b = new Rect(left + lw + g, top2, right, l.area.bottom);
        int leftSlot = swapped ? 1 : 0;
        l.pane[leftSlot].set(a);
        l.pane[1 - leftSlot].set(b);
        int cx = left + lw + g / 2;
        int cy = l.area.centerY();
        int hw = Math.max(2, Math.round(3 * dpi / 160f));
        int hh = Math.round(44 * dpi / 160f);
        l.handle.set(cx - hw, cy - hh / 2, cx + hw, cy + hh / 2);
        int gw = Math.round(28 * dpi / 160f);
        l.grab.set(cx - gw, top2, cx + gw, l.area.bottom);
        return l;
    }

    /** The slot whose pane holds this point, or -1. */
    int slotAt(int x, int y) {
        for (int i = 0; i < 2; i++) {
            if (!pane[i].isEmpty() && pane[i].contains(x, y)) return i;
        }
        return -1;
    }

    /** Share of the width the left pane has now (for resizing). */
    float leftShare() {
        int total = area.width() - gap;
        if (!split || total <= 0) return 0.5f;
        Rect left = pane[0].left <= pane[1].left ? pane[0] : pane[1];
        return left.width() / (float) total;
    }
}
