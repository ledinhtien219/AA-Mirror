package com.mag.anyauto;

import android.service.notification.NotificationListenerService;

/**
 * Does nothing itself. Android only lets an app list the active media sessions (the song on the
 * top bar and its buttons) when it holds notification access, and that is granted to a
 * NotificationListenerService, so {@link MediaWatcher} names this one.
 */
public final class MediaListenerService extends NotificationListenerService {
}
