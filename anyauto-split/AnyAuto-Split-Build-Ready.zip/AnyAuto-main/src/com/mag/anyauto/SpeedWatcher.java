package com.mag.anyauto;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.Looper;
import android.os.SystemClock;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * The speed warning: the GPS speed, and the speed limit of the road under the car from
 * OpenStreetMap (an Overpass query for the nearest way with a maxspeed tag, asked now and then
 * while the car moves). No limit known = no sign, only the plain speed. Needs the location
 * permission; without it nothing shows.
 */
final class SpeedWatcher implements LocationListener {
    private static final String TAG = "AnyAuto";
    private static final String OVERPASS = "https://overpass-api.de/api/interpreter";
    private static final float MOVING_KMH = 5f;
    private static final float REQUERY_M = 60f;
    private static final long REQUERY_MS = 30_000, LIMIT_TTL_MS = 180_000;

    interface Listener {
        /** Any thread. */
        void onSpeed();
    }

    private final Context context;
    private final Listener listener;
    private final Looper looper;
    private LocationManager lm;
    private boolean started;
    private final ExecutorService net = Executors.newSingleThreadExecutor();
    private Location queried;
    private long queriedAt, limitAt;
    private volatile boolean querying;

    volatile int speed = -1, limit = -1;

    SpeedWatcher(Context context, Looper looper, Listener listener) {
        this.context = context.getApplicationContext();
        this.looper = looper;
        this.listener = listener;
    }

    static boolean hasPermission(Context c) {
        return c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    void start() {
        if (started || !hasPermission(context)) return;
        try {
            lm = context.getSystemService(LocationManager.class);
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this, looper);
            started = true;
        } catch (RuntimeException e) {
            Log.i(TAG, "speed: no GPS: " + e);
        }
    }

    void stop() {
        if (!started) return;
        started = false;
        try {
            lm.removeUpdates(this);
        } catch (RuntimeException ignore) {
            // gone already
        }
        speed = -1;
        limit = -1;
    }

    void release() {
        stop();
        net.shutdownNow();
    }

    @Override
    public void onLocationChanged(Location l) {
        int s = l.hasSpeed() ? Math.round(l.getSpeed() * 3.6f) : -1;
        boolean changed = s != speed;
        speed = s;
        long now = SystemClock.elapsedRealtime();
        if (limit > 0 && now - limitAt > LIMIT_TTL_MS) {
            limit = -1;
            changed = true;
        }
        if (s >= MOVING_KMH && !querying && (queried == null || now - queriedAt > REQUERY_MS
                || l.distanceTo(queried) > REQUERY_M)) {
            query(l, now);
        }
        if (changed) listener.onSpeed();
    }

    private void query(Location l, long now) {
        querying = true;
        queried = new Location(l);
        queriedAt = now;
        final double lat = l.getLatitude(), lon = l.getLongitude();
        net.execute(() -> {
            try {
                int v = fetchLimit(lat, lon);
                if (v > 0) {
                    limitAt = SystemClock.elapsedRealtime();
                    if (v != limit) {
                        limit = v;
                        listener.onSpeed();
                    }
                }
            } catch (Exception e) {
                Log.i(TAG, "speed limit lookup failed: " + e);
            } finally {
                querying = false;
            }
        });
    }

    /** The maxspeed (km/h) of the nearest road within 25 m, or -1. */
    private static int fetchLimit(double lat, double lon) throws Exception {
        String q = String.format(Locale.US, "[out:json][timeout:6];way(around:25,%.6f,%.6f)[highway][maxspeed];out tags 5;", lat, lon);
        HttpURLConnection c = (HttpURLConnection) new URL(OVERPASS + "?data=" + URLEncoder.encode(q, "UTF-8")).openConnection();
        c.setConnectTimeout(5000);
        c.setReadTimeout(7000);
        c.setRequestProperty("User-Agent", "AnyAuto-Split/1.0");
        try {
            if (c.getResponseCode() != 200) return -1;
            StringBuilder sb = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) sb.append(line);
            }
            JSONArray els = new JSONObject(sb.toString()).optJSONArray("elements");
            if (els == null) return -1;
            for (int i = 0; i < els.length(); i++) {
                JSONObject tags = els.getJSONObject(i).optJSONObject("tags");
                int v = tags == null ? -1 : parse(tags.optString("maxspeed", ""));
                if (v > 0) return v;
            }
            return -1;
        } finally {
            c.disconnect();
        }
    }

    /** "50" → 50, "30 mph" → 48, "none" or anything else → -1. */
    static int parse(String s) {
        if (s == null) return -1;
        s = s.trim().toLowerCase(Locale.US);
        int i = 0;
        while (i < s.length() && Character.isDigit(s.charAt(i))) i++;
        if (i == 0) return -1;
        int v = Integer.parseInt(s.substring(0, i));
        if (s.contains("mph")) v = Math.round(v * 1.609f);
        return v;
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
        speed = -1;
        listener.onSpeed();
    }
}
