package com.mag.anyauto;

import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.TextPaint;
import android.text.TextUtils;

/**
 * The top bar of the split screen, drawn with a Canvas into a bitmap of the bar's size (the
 * compositor puts it on the car surface). Left to right: Home, the apps list (CH), the speed
 * sign, the song (art, title, artist) with previous / play / next, the clock pill, the
 * connection icons, swap the two apps, split / single screen.
 *
 * <p>Everything is positioned by fractions of the bar's width, the same ones {@link #hit} uses to
 * find the tapped button, so drawing and touching can't drift apart. Icons are paths, no
 * resources.
 */
final class TopBar {
    static final int NONE = -1, HOME = 0, APPS = 1, PREV = 2, PLAY = 3, NEXT = 4, SWAP = 5, SPLIT = 6;
    // button centres as a share of the bar's width, in the order of the ids above
    private static final float[] FX = {0.046f, 0.100f, 0.492f, 0.532f, 0.572f, 0.923f, 0.962f};
    private static final float SPEED_X = 0.252f;
    private static final float MEDIA_L = 0.348f, MEDIA_R = 0.595f;
    private static final float CLOCK_L = 0.608f, CLOCK_R = 0.748f;
    private static final float[] STATUS_X = {0.778f, 0.810f, 0.842f}; // signal, bluetooth, wifi

    static final int BAR_BG = 0xFF0D151E, PILL_BG = 0xFF131D29;
    private static final int ICON = 0xFFE6EDF5, DIM = 0x55E6EDF5, ACCENT = 0xFF5B8DEF;

    /** What the bar shows. */
    static final class State {
        String time = "", date = "";
        boolean hasMedia, playing;
        String title, artist;
        Bitmap art;
        int limit = -1, speed = -1;   // km/h, -1 unknown
        boolean over, blink;
        boolean wifi, bt;
        int bars = -1;                // mobile signal 0..4, -1 unknown
        boolean split = true;
    }

    private TopBar() {
    }

    /** The button at (x, y) of a bar of w × h (bar-relative pixels), or {@link #NONE}. */
    static int hit(int w, int h, float x, float y) {
        if (y < 0 || y > h || x < 0 || x > w) return NONE;
        if (x >= 0.082f * w && x <= 0.15f * w) return APPS; // the icon and its label
        int best = NONE;
        float bestD = h * 0.55f;
        for (int i = 0; i < FX.length; i++) {
            float d = Math.abs(x - FX[i] * w);
            if (d <= bestD) {
                best = i;
                bestD = d;
            }
        }
        return best;
    }

    static Bitmap render(int w, int h, State st) {
        Bitmap b = Bitmap.createBitmap(Math.max(1, w), Math.max(1, h), Bitmap.Config.ARGB_8888);
        Canvas c = new Canvas(b);
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float rad = h * 0.32f;
        p.setColor(BAR_BG);
        c.drawRoundRect(new RectF(0, 0, w, h), rad, rad, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(1f, h / 56f));
        p.setColor(0x24FFFFFF);
        float in = p.getStrokeWidth() / 2;
        c.drawRoundRect(new RectF(in, in, w - in, h - in), rad, rad, p);
        p.setStyle(Paint.Style.FILL);

        float is = h * 0.44f, cy = h / 2f;
        icon(c, HOME, FX[HOME] * w, cy, is, ICON);
        icon(c, APPS, FX[APPS] * w, cy, is * 0.9f, ICON);
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        tp.setColor(ICON);
        tp.setTextSize(h * 0.27f);
        c.drawText("CH", FX[APPS] * w + is * 0.62f, cy + h * 0.095f, tp);

        speed(c, SPEED_X * w, cy, h * 0.42f, st);
        media(c, w, h, st, tp);
        clock(c, w, h, st, tp);

        float ss = is * 0.8f;
        signal(c, STATUS_X[0] * w, cy, ss, st.bars);
        icon(c, -2, STATUS_X[1] * w, cy, ss, st.bt ? ICON : DIM); // bluetooth
        icon(c, -3, STATUS_X[2] * w, cy, ss, st.wifi ? ICON : DIM); // wifi

        icon(c, SWAP, FX[SWAP] * w, cy, is, ICON);
        icon(c, SPLIT, FX[SPLIT] * w, cy, is, st.split ? ACCENT : ICON);
        return b;
    }

    // ------------------------------------------------------------------ parts

    private static void speed(Canvas c, float cx, float cy, float r, State st) {
        if (st.limit <= 0 && st.speed < 0) return;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        boolean sign = st.limit > 0;
        int value = sign ? st.limit : st.speed;
        if (sign && st.over) {
            p.setColor(st.blink ? 0x66FF3B30 : 0x33FF3B30);
            c.drawCircle(cx, cy, r * 1.14f, p);
        }
        p.setColor(Color_WHITE);
        c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(r * 0.2f);
        p.setColor(sign ? (st.over && st.blink ? 0xFFFF1A12 : 0xFFD7261E) : 0xFF8A94A0);
        c.drawCircle(cx, cy, r * 0.88f, p);
        TextPaint tp = new TextPaint(Paint.ANTI_ALIAS_FLAG);
        tp.setTypeface(Typeface.create("sans-serif", Typeface.BOLD));
        tp.setColor(0xFF10151B);
        tp.setTextAlign(Paint.Align.CENTER);
        String t = String.valueOf(value);
        tp.setTextSize(r * (t.length() >= 3 ? 0.72f : 0.92f));
        c.drawText(t, cx, cy + tp.getTextSize() * 0.36f, tp);
    }

    private static final int Color_WHITE = 0xFFFFFFFF;

    private static void media(Canvas c, int w, int h, State st, TextPaint tp) {
        float l = MEDIA_L * w, r = MEDIA_R * w;
        pill(c, l, r, h, PILL_BG);
        float cy = h / 2f, ad = h * 0.62f;
        float ax = l + h * 0.14f + ad / 2f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        if (st.art != null) {
            Path clip = new Path();
            clip.addCircle(ax, cy, ad / 2f, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            c.drawBitmap(st.art, null, new RectF(ax - ad / 2f, cy - ad / 2f, ax + ad / 2f, cy + ad / 2f), p);
            c.restore();
        } else {
            p.setColor(0xFF223041);
            c.drawCircle(ax, cy, ad / 2f, p);
            p.setColor(0xAAE6EDF5);
            float s = ad * 0.5f;
            c.drawCircle(ax - s * 0.12f, cy + s * 0.28f, s * 0.2f, p);
            p.setStrokeWidth(s * 0.12f);
            p.setStyle(Paint.Style.STROKE);
            c.drawLine(ax + s * 0.06f, cy + s * 0.2f, ax + s * 0.06f, cy - s * 0.4f, p);
        }
        float tx = ax + ad / 2f + h * 0.16f;
        float tw = FX[PREV] * w - h * 0.42f - tx;
        if (tw > h) {
            TextPaint t = new TextPaint(tp);
            t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            t.setColor(st.hasMedia ? 0xFFFFFFFF : 0x99FFFFFF);
            t.setTextSize(h * 0.27f);
            String title = st.hasMedia && !TextUtils.isEmpty(st.title) ? st.title : "Chưa phát nhạc";
            c.drawText(TextUtils.ellipsize(title, t, tw, TextUtils.TruncateAt.END).toString(), tx, cy - h * 0.04f, t);
            if (st.hasMedia && !TextUtils.isEmpty(st.artist)) {
                t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
                t.setColor(0x99FFFFFF);
                t.setTextSize(h * 0.2f);
                c.drawText(TextUtils.ellipsize(st.artist, t, tw, TextUtils.TruncateAt.END).toString(), tx, cy + h * 0.24f, t);
            }
        }
        int fg = st.hasMedia ? ICON : DIM;
        float s = h * 0.34f;
        icon(c, PREV, FX[PREV] * w, cy, s, fg);
        icon(c, st.playing ? -1 : PLAY, FX[PLAY] * w, cy, s * 1.1f, fg);
        icon(c, NEXT, FX[NEXT] * w, cy, s, fg);
    }

    private static void clock(Canvas c, int w, int h, State st, TextPaint base) {
        float l = CLOCK_L * w, r = CLOCK_R * w;
        pill(c, l, r, h, PILL_BG);
        TextPaint t = new TextPaint(base);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        TextPaint d = new TextPaint(base);
        d.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        d.setColor(0x99FFFFFF);
        float pad = h * 0.3f, gap = h * 0.22f;
        t.setTextSize(h * 0.36f);
        d.setTextSize(h * 0.24f);
        float need = t.measureText(st.time) + gap + d.measureText(st.date);
        float k = Math.min(1f, (r - l - 2 * pad) / Math.max(1f, need));
        t.setTextSize(h * 0.36f * k);
        d.setTextSize(h * 0.24f * k);
        float tw = t.measureText(st.time), dw = d.measureText(st.date);
        float x = l + ((r - l) - (tw + gap * k + dw)) / 2f;
        c.drawText(st.time, x, h / 2f + t.getTextSize() * 0.36f, t);
        c.drawText(st.date, x + tw + gap * k, h / 2f + t.getTextSize() * 0.36f, d);
    }

    private static void pill(Canvas c, float l, float r, int h, int color) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setColor(color);
        float t = h * 0.12f, b = h * 0.88f;
        c.drawRoundRect(new RectF(l, t, r, b), (b - t) / 2f, (b - t) / 2f, p);
    }

    private static void signal(Canvas c, float cx, float cy, float s, int bars) {
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        float bw = s * 0.16f, gap = s * 0.08f, x = cx - (4 * bw + 3 * gap) / 2f;
        int on = bars < 0 ? 0 : bars;
        for (int i = 0; i < 4; i++) {
            float bh = s * (0.3f + 0.2f * i);
            p.setColor(i < on ? ICON : DIM);
            c.drawRoundRect(new RectF(x, cy + s * 0.5f - bh, x + bw, cy + s * 0.5f), bw / 3f, bw / 3f, p);
            x += bw + gap;
        }
    }

    // ------------------------------------------------------------------ icons

    /**
     * One icon centred at (cx, cy), about s px. Ids: the button ids, -1 = pause, -2 = bluetooth,
     * -3 = wifi.
     */
    static void icon(Canvas c, int id, float cx, float cy, float s, int color) {
        Paint f = new Paint(Paint.ANTI_ALIAS_FLAG);
        f.setColor(color);
        Paint k = new Paint(Paint.ANTI_ALIAS_FLAG);
        k.setColor(color);
        k.setStyle(Paint.Style.STROKE);
        k.setStrokeCap(Paint.Cap.ROUND);
        k.setStrokeJoin(Paint.Join.ROUND);
        k.setStrokeWidth(s * 0.09f);
        Path q = new Path();
        switch (id) {
            case HOME:
                poly(q, cx, cy, s, 0, -0.5f, 0.5f, -0.02f, 0.38f, -0.02f, 0.38f, 0.46f, 0.12f, 0.46f, 0.12f, 0.12f,
                        -0.12f, 0.12f, -0.12f, 0.46f, -0.38f, 0.46f, -0.38f, -0.02f, -0.5f, -0.02f);
                q.close();
                c.drawPath(q, f);
                break;
            case APPS:
                k.setStrokeWidth(s * 0.07f);
                for (int i = 0; i < 4; i++) {
                    c.drawCircle(cx + (i % 2 == 0 ? -0.22f : 0.22f) * s, cy + (i < 2 ? -0.22f : 0.22f) * s, s * 0.15f, k);
                }
                break;
            case PREV:
                c.drawRect(cx - 0.36f * s, cy - 0.32f * s, cx - 0.27f * s, cy + 0.32f * s, f);
                poly(q, cx, cy, s, 0.34f, -0.34f, -0.2f, 0, 0.34f, 0.34f);
                q.close();
                c.drawPath(q, f);
                break;
            case NEXT:
                c.drawRect(cx + 0.27f * s, cy - 0.32f * s, cx + 0.36f * s, cy + 0.32f * s, f);
                poly(q, cx, cy, s, -0.34f, -0.34f, 0.2f, 0, -0.34f, 0.34f);
                q.close();
                c.drawPath(q, f);
                break;
            case PLAY:
                poly(q, cx, cy, s, -0.24f, -0.38f, 0.4f, 0, -0.24f, 0.38f);
                q.close();
                c.drawPath(q, f);
                break;
            case -1: // pause
                c.drawRoundRect(new RectF(cx - 0.3f * s, cy - 0.36f * s, cx - 0.08f * s, cy + 0.36f * s), s * 0.05f, s * 0.05f, f);
                c.drawRoundRect(new RectF(cx + 0.08f * s, cy - 0.36f * s, cx + 0.3f * s, cy + 0.36f * s), s * 0.05f, s * 0.05f, f);
                break;
            case SWAP:
                poly(q, cx, cy, s, -0.4f, -0.17f, 0.4f, -0.17f);
                poly(q, cx, cy, s, 0.22f, -0.35f, 0.4f, -0.17f, 0.22f, 0.01f);
                poly(q, cx, cy, s, 0.4f, 0.17f, -0.4f, 0.17f);
                poly(q, cx, cy, s, -0.22f, -0.01f, -0.4f, 0.17f, -0.22f, 0.35f);
                c.drawPath(q, k);
                break;
            case SPLIT:
                k.setStrokeWidth(s * 0.08f);
                c.drawRoundRect(new RectF(cx - 0.5f * s, cy - 0.4f * s, cx - 0.06f * s, cy + 0.4f * s), s * 0.1f, s * 0.1f, k);
                c.drawRoundRect(new RectF(cx + 0.06f * s, cy - 0.4f * s, cx + 0.5f * s, cy + 0.4f * s), s * 0.1f, s * 0.1f, f);
                break;
            case -2: // bluetooth
                poly(q, cx, cy, s, -0.25f, -0.25f, 0.25f, 0.25f, 0, 0.5f, 0, -0.5f, 0.25f, -0.25f, -0.25f, 0.25f);
                c.drawPath(q, k);
                break;
            case -3: // wifi
                k.setStrokeWidth(s * 0.1f);
                for (int i = 1; i <= 3; i++) {
                    float r = s * 0.2f * i;
                    c.drawArc(new RectF(cx - r, cy + s * 0.32f - r, cx + r, cy + s * 0.32f + r), 225, 90, false, k);
                }
                c.drawCircle(cx, cy + s * 0.32f, s * 0.06f, f);
                break;
            default:
                break;
        }
    }

    /** A polyline through the points (x, y pairs, in units of s around the centre). */
    private static void poly(Path q, float cx, float cy, float s, float... pts) {
        for (int i = 0; i + 1 < pts.length; i += 2) {
            float x = cx + pts[i] * s, y = cy + pts[i + 1] * s;
            if (i == 0) q.moveTo(x, y);
            else q.lineTo(x, y);
        }
    }
}
