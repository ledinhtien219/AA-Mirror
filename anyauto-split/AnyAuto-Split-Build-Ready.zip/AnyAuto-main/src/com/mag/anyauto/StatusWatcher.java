package com.mag.anyauto;

import android.bluetooth.BluetoothAdapter;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.util.Log;

/**
 * The connection icons: Wi-Fi (the default network is Wi-Fi), Bluetooth (switched on) and the
 * mobile signal bars. Everything is best effort: a phone that won't tell shows the icon dim.
 */
final class StatusWatcher {
    private static final String TAG = "AnyAuto";

    interface Listener {
        /** Any thread. */
        void onStatus();
    }

    private final Context context;
    private final Listener listener;
    private final Handler handler;
    private ConnectivityManager cm;
    private boolean started;

    volatile boolean wifi, bt;
    volatile int bars = -1;

    private final ConnectivityManager.NetworkCallback netCallback = new ConnectivityManager.NetworkCallback() {
        @Override
        public void onCapabilitiesChanged(Network n, NetworkCapabilities c) {
            refresh();
        }

        @Override
        public void onLost(Network n) {
            refresh();
        }
    };
    private final BroadcastReceiver btReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context c, Intent i) {
            refresh();
        }
    };

    StatusWatcher(Context context, Handler handler, Listener listener) {
        this.context = context.getApplicationContext();
        this.handler = handler;
        this.listener = listener;
    }

    void start() {
        if (started) return;
        started = true;
        try {
            cm = context.getSystemService(ConnectivityManager.class);
            cm.registerDefaultNetworkCallback(netCallback, handler);
        } catch (RuntimeException e) {
            Log.i(TAG, "status: no network callback: " + e);
        }
        try {
            context.registerReceiver(btReceiver, new IntentFilter(BluetoothAdapter.ACTION_STATE_CHANGED), null, handler);
        } catch (RuntimeException e) {
            Log.i(TAG, "status: no bluetooth receiver: " + e);
        }
        refresh();
    }

    void stop() {
        if (!started) return;
        started = false;
        try {
            if (cm != null) cm.unregisterNetworkCallback(netCallback);
        } catch (RuntimeException ignore) {
            // not registered
        }
        try {
            context.unregisterReceiver(btReceiver);
        } catch (RuntimeException ignore) {
            // not registered
        }
    }

    /** Reads everything again (also called by the bar's minute tick: signal bars change quietly). */
    void refresh() {
        boolean w = false, b = false;
        int s = -1;
        try {
            if (cm != null) {
                Network n = cm.getActiveNetwork();
                NetworkCapabilities c = n == null ? null : cm.getNetworkCapabilities(n);
                w = c != null && c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
            }
        } catch (RuntimeException ignore) {
            // unknown
        }
        try {
            BluetoothAdapter a = BluetoothAdapter.getDefaultAdapter();
            b = a != null && a.isEnabled();
        } catch (RuntimeException ignore) {
            // no permission on this Android
        }
        try {
            TelephonyManager t = context.getSystemService(TelephonyManager.class);
            SignalStrength ss = t == null ? null : t.getSignalStrength();
            if (ss != null) s = Math.max(0, Math.min(4, ss.getLevel()));
        } catch (RuntimeException ignore) {
            // needs a permission on some phones: no bars
        }
        if (w != wifi || b != bt || s != bars) {
            wifi = w;
            bt = b;
            bars = s;
            listener.onStatus();
        }
    }
}
